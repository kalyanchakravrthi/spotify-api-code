module.exports = {
  dialect: 'sqlite',
  storage: process.env.STORAGE,
};
